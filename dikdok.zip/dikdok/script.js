/* =========================================================================
   DIKDOK FIREBASE CORE ENGINE
   Features: Auth, Firestore Feeds, Video Upload, Likes, Comments, LIVE, DM
   ========================================================================= */

// 1. Firebase SDK Imports (Modular v10 CDN)
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { 
  getFirestore, 
  collection, 
  addDoc, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where, 
  orderBy, 
  serverTimestamp, 
  arrayUnion, 
  arrayRemove, 
  increment 
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { 
  getStorage, 
  ref, 
  uploadBytesResumable, 
  getDownloadURL 
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";

// ==========================================
// আপনার Firebase Configuration এখানে বসান
// ==========================================
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);
const googleProvider = new GoogleAuthProvider();

// Global App States
let currentUser = null;
let currentActiveVideoId = null;
let selectedVideoFile = null;
let isAutoScrollOn = false;
let autoScrollTimer = null;
let activeCommentsUnsubscribe = null;
let activeLiveChatUnsubscribe = null;

// ==========================================
// 1. AUTHENTICATION (Google Login & Profile)
// ==========================================
onAuthStateChanged(auth, async (user) => {
  if (user) {
    currentUser = user;
    document.getElementById('nav-user-avatar').src = user.photoURL || 'https://i.pravatar.cc/150?img=68';
    document.getElementById('user-profile-img').src = user.photoURL || 'https://i.pravatar.cc/150?img=68';
    document.getElementById('user-profile-name').textContent = user.displayName || 'DIKDOK User';
    
    // Check or create user profile in Firestore
    const userDocRef = doc(db, "users", user.uid);
    const userSnap = await getDoc(userDocRef);

    if (!userSnap.exists()) {
      await setDoc(userDocRef, {
        uid: user.uid,
        name: user.displayName,
        username: "@" + user.email.split('@')[0],
        photo: user.photoURL,
        diamonds: 0,
        following: [],
        followersCount: 0,
        lastUsernameChange: null,
        createdAt: serverTimestamp()
      });
    } else {
      const data = userSnap.data();
      document.getElementById('user-profile-handle').innerHTML = `${data.username} <span class="badge">১০ দিনে ১ বার পরিবর্তনযোগ্য</span>`;
      document.getElementById('following-count').textContent = (data.following || []).length;
      document.getElementById('followers-count').textContent = data.followersCount || 0;
    }
  } else {
    currentUser = null;
    document.getElementById('user-profile-name').textContent = 'Guest User';
    document.getElementById('user-profile-handle').textContent = '@guest';
  }
});

window.loginWithGoogle = async function() {
  try {
    await signInWithPopup(auth, googleProvider);
    closeModal('auth-modal');
    alert('সফলভাবে লগইন হয়েছে!');
  } catch (error) {
    console.error("Login Error:", error);
    alert('লগইন ত্রুটি: ' + error.message);
  }
};

window.logoutUser = async function() {
  if (confirm("আপনি কি লগআউট করতে চান?")) {
    await signOut(auth);
    alert('লগআউট সফল হয়েছে!');
    closeModal('profile-modal');
  }
};

// ==========================================
// 2. VIDEO FEED & FIRESTORE REALTIME SYNC
// ==========================================
const sampleVideos = [
  {
    id: "sample-1",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-young-woman-skater-performing-tricks-in-a-skatepark-42969-large.mp4",
    creator: "@shakib_dev",
    creatorAvatar: "https://i.pravatar.cc/150?img=11",
    description: "DIKDOK অ্যাপে স্বাগতম! ফায়ারবেস ইন্টিগ্রেটেড 🚀 #viral #fyp",
    category: "fyp",
    likes: ["guest1", "guest2"],
    commentsCount: 2,
    audio: "Original Audio - DIKDOK Official"
  },
  {
    id: "sample-2",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-circuit-board-with-glowing-green-lines-41559-large.mp4",
    creator: "@tech_master",
    creatorAvatar: "https://i.pravatar.cc/150?img=33",
    description: "কম্পিউটার প্রসেসর কীভাবে কাজ করে? 💻⚡ #science #STEM #tech",
    category: "stem",
    likes: ["user10"],
    commentsCount: 1,
    audio: "STEM Science Theme Beat"
  }
];

function loadVideos(filterCategory = 'fyp') {
  const feed = document.getElementById('video-feed');
  const q = collection(db, "videos");

  // Realtime Firestore Listener for Videos
  onSnapshot(q, (snapshot) => {
    let videos = [];
    snapshot.forEach(docSnap => {
      videos.push({ id: docSnap.id, ...docSnap.data() });
    });

    // If Firestore has no videos yet, fallback to sample demo videos
    if (videos.length === 0) {
      videos = sampleVideos;
    }

    if (filterCategory !== 'fyp') {
      videos = videos.filter(v => v.category === filterCategory);
    }

    renderFeed(videos);
  });
}

function renderFeed(videos) {
  const feed = document.getElementById('video-feed');
  feed.innerHTML = '';

  if (videos.length === 0) {
    feed.innerHTML = `<div class="feed-loader"><p>এই ক্যাটাগরিতে কোনো ভিডিও নেই!</p></div>`;
    return;
  }

  videos.forEach((video, index) => {
    const isLiked = currentUser && video.likes?.includes(currentUser.uid);
    const likesCount = video.likes ? video.likes.length : 0;

    const card = document.createElement('section');
    card.className = 'video-card';
    card.dataset.id = video.id;

    card.innerHTML = `
      <video class="player" loop playsinline src="${video.videoUrl}"></video>
      <div class="double-tap-heart"><i class="fa-solid fa-heart"></i></div>

      <div class="video-meta">
        <div class="creator-info">
          <span class="username">${video.creator}</span>
          <button class="btn-follow" onclick="handleFollow('${video.creatorUid || ''}', this)">+ Follow</button>
        </div>
        <p class="description">${video.description}</p>
        <div class="sound-track">
          <i class="fa-solid fa-music"></i>
          <marquee scrollamount="4">${video.audio || 'Original Sound - DIKDOK'}</marquee>
        </div>
      </div>

      <div class="action-sidebar">
        <div class="action-item avatar-wrapper">
          <img src="${video.creatorAvatar || 'https://i.pravatar.cc/150?img=12'}" alt="Creator">
        </div>
        <div class="action-item like-btn ${isLiked ? 'liked' : ''}" onclick="toggleLike('${video.id}', this)">
          <i class="fa-solid fa-heart"></i>
          <span class="count">${likesCount}</span>
        </div>
        <div class="action-item" onclick="openCommentsDrawer('${video.id}')">
          <i class="fa-solid fa-comment-dots"></i>
          <span class="count">${video.commentsCount || 0}</span>
        </div>
        <div class="action-item bookmark-btn" onclick="toggleBookmark('${video.id}', this)">
          <i class="fa-solid fa-bookmark"></i>
          <span class="count">Save</span>
        </div>
        <div class="action-item" onclick="openShareDrawer('${video.id}')">
          <i class="fa-solid fa-share"></i>
          <span class="count">Share</span>
        </div>
      </div>
    `;

    setupCardInteractions(card);
    feed.appendChild(card);

    // Auto-play first video
    if (index === 0) {
      currentActiveVideoId = video.id;
      const vid = card.querySelector('video');
      vid.play().catch(() => console.log("Autoplay waiting for user touch"));
    }
  });
}

function setupCardInteractions(card) {
  const video = card.querySelector('.player');
  const heart = card.querySelector('.double-tap-heart');
  const videoId = card.dataset.id;
  let lastTap = 0;

  card.addEventListener('click', (e) => {
    if (e.target.closest('.action-sidebar') || e.target.closest('.video-meta')) return;

    const currentTime = new Date().getTime();
    if (currentTime - lastTap < 300) {
      // Double tap triggered
      heart.classList.add('animate');
      setTimeout(() => heart.classList.remove('animate'), 600);
      window.toggleLike(videoId, card.querySelector('.like-btn'), true);
    } else {
      if (video.paused) video.play();
      else video.pause();
    }
    lastTap = currentTime;
  });
}

// ==========================================
// 3. LIKES & REALTIME TOGGLE
// ==========================================
window.toggleLike = async function(videoId, btnElement, forceLike = false) {
  if (!currentUser) {
    openModal('auth-modal');
    return;
  }

  const isLiked = btnElement.classList.contains('liked');
  const countSpan = btnElement.querySelector('.count');
  let count = parseInt(countSpan.textContent) || 0;

  try {
    const videoRef = doc(db, "videos", videoId);
    if (!isLiked || forceLike) {
      btnElement.classList.add('liked');
      countSpan.textContent = count + 1;
      await updateDoc(videoRef, { likes: arrayUnion(currentUser.uid) });
    } else {
      btnElement.classList.remove('liked');
      countSpan.textContent = Math.max(0, count - 1);
      await updateDoc(videoRef, { likes: arrayRemove(currentUser.uid) });
    }
  } catch (err) {
    console.log("Mock video like toggled locally");
  }
};

// ==========================================
// 4. REALTIME COMMENTS (Firestore Subcollection)
// ==========================================
window.openCommentsDrawer = function(videoId) {
  currentActiveVideoId = videoId;
  const drawer = document.getElementById('comments-drawer');
  drawer.classList.add('open');

  if (activeCommentsUnsubscribe) activeCommentsUnsubscribe();

  const commentsRef = collection(db, `videos/${videoId}/comments`);
  const q = query(commentsRef, orderBy("createdAt", "desc"));

  activeCommentsUnsubscribe = onSnapshot(q, (snapshot) => {
    const list = document.getElementById('comments-list');
    list.innerHTML = '';
    document.getElementById('total-comments').textContent = snapshot.size;

    snapshot.forEach(docSnap => {
      const data = docSnap.data();
      const canDelete = currentUser && (currentUser.uid === data.uid);

      const item = document.createElement('div');
      item.className = 'comment-item';
      item.innerHTML = `
        <img src="${data.userPhoto || 'https://i.pravatar.cc/150?img=60'}" alt="User">
        <div class="comment-body">
          <h6>${data.userName}</h6>
          <p>${escapeHtml(data.text)}</p>
        </div>
        ${canDelete ? `<button class="comment-del" onclick="deleteFirebaseComment('${videoId}', '${docSnap.id}')"><i class="fa-regular fa-trash-can"></i></button>` : ''}
      `;
      list.appendChild(item);
    });
  });
};

window.postComment = async function() {
  if (!currentUser) {
    openModal('auth-modal');
    return;
  }

  const input = document.getElementById('new-comment-input');
  const text = input.value.trim();
  if (!text || !currentActiveVideoId) return;

  try {
    await addDoc(collection(db, `videos/${currentActiveVideoId}/comments`), {
      uid: currentUser.uid,
      userName: currentUser.displayName || "@user",
      userPhoto: currentUser.photoURL || "",
      text: text,
      createdAt: serverTimestamp()
    });

    await updateDoc(doc(db, "videos", currentActiveVideoId), {
      commentsCount: increment(1)
    }).catch(() => {});

    input.value = '';
  } catch (e) {
    console.error("Comment post error:", e);
  }
};

window.deleteFirebaseComment = async function(videoId, commentId) {
  if (confirm("কমেন্টটি ডিলিট করতে চান?")) {
    await deleteDoc(doc(db, `videos/${videoId}/comments`, commentId));
    await updateDoc(doc(db, "videos", videoId), {
      commentsCount: increment(-1)
    }).catch(() => {});
  }
};

// ==========================================
// 5. VIDEO UPLOAD (Firebase Cloud Storage)
// ==========================================
window.handleFileSelected = function(event) {
  selectedVideoFile = event.target.files[0];
  if (selectedVideoFile) {
    document.getElementById('upload-meta-form').style.display = 'flex';
  }
};

window.uploadVideoToFirebase = async function() {
  if (!currentUser) {
    openModal('auth-modal');
    return;
  }
  if (!selectedVideoFile) {
    alert("অনুগ্রহ করে একটি ভিডিও ফাইল নির্বাচন করুন!");
    return;
  }

  const caption = document.getElementById('video-caption').value || "DIKDOK New Video";
  const category = document.getElementById('video-category').value;
  const progressWrap = document.getElementById('upload-progress-wrap');
  const progressFill = document.getElementById('upload-progress-fill');

  progressWrap.style.display = 'block';

  try {
    const fileRef = ref(storage, `videos/${Date.now()}_${selectedVideoFile.name}`);
    const uploadTask = uploadBytesResumable(fileRef, selectedVideoFile);

    uploadTask.on('state_changed', 
      (snapshot) => {
        const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        progressFill.style.width = percent + '%';
      }, 
      (error) => {
        console.error("Storage Upload Error:", error);
        alert("ভিডিও আপলোডে সমস্যা হয়েছে: " + error.message);
      }, 
      async () => {
        const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
        
        // Save metadata to Firestore
        await addDoc(collection(db, "videos"), {
          videoUrl: downloadUrl,
          creator: currentUser.displayName || "@user",
          creatorUid: currentUser.uid,
          creatorAvatar: currentUser.photoURL || "https://i.pravatar.cc/150?img=12",
          description: caption,
          category: category,
          likes: [],
          commentsCount: 0,
          createdAt: serverTimestamp()
        });

        alert("ভিডিও সফলভাবে আপলোড হয়েছে! ফিডে যুক্ত করা হয়েছে। 🔥");
        closeModal('camera-modal');
        progressWrap.style.display = 'none';
      }
    );
  } catch (e) {
    console.error("Upload error:", e);
  }
};

// ==========================================
// 6. REALTIME LIVE STREAM & VIRTUAL GIFTS
// ==========================================
document.getElementById('live-open-btn').addEventListener('click', () => {
  openModal('live-modal');
  setupLiveRealtime();
});

function setupLiveRealtime() {
  if (activeLiveChatUnsubscribe) activeLiveChatUnsubscribe();

  const liveChatRef = collection(db, "live_stream_chats");
  const q = query(liveChatRef, orderBy("createdAt", "asc"));

  activeLiveChatUnsubscribe = onSnapshot(q, (snapshot) => {
    const chatBox = document.getElementById('live-chat-flow');
    chatBox.innerHTML = '';
    snapshot.forEach(docSnap => {
      const data = docSnap.data();
      const msg = document.createElement('p');
      msg.innerHTML = `<span>${data.user}:</span> ${escapeHtml(data.text)}`;
      chatBox.appendChild(msg);
    });
    chatBox.scrollTop = chatBox.scrollHeight;
  });
}

window.sendLiveChatMessage = async function() {
  const input = document.getElementById('live-chat-msg');
  const text = input.value.trim();
  if (!text) return;

  await addDoc(collection(db, "live_stream_chats"), {
    user: currentUser ? currentUser.displayName : "@guest",
    text: text,
    createdAt: serverTimestamp()
  });

  input.value = '';
};

window.sendFirebaseGift = async function(giftName, diamonds) {
  const diamondCountElem = document.getElementById('live-diamonds');
  let currentVal = parseInt(diamondCountElem.textContent) || 0;
  diamondCountElem.textContent = currentVal + diamonds;

  // Add Gift Announcement to Live Chat
  await addDoc(collection(db, "live_stream_chats"), {
    user: currentUser ? currentUser.displayName : "@guest",
    text: `একটি ${giftName} পাঠিয়েছেন (+${diamonds} 💎)!`,
    createdAt: serverTimestamp()
  });
};

// ==========================================
// 7. USERNAME 10-DAY RESTRICTION CHECK
// ==========================================
window.triggerEditUsername = async function() {
  if (!currentUser) {
    openModal('auth-modal');
    return;
  }

  const userDocRef = doc(db, "users", currentUser.uid);
  const snap = await getDoc(userDocRef);
  const userData = snap.data();

  if (userData.lastUsernameChange) {
    const lastChange = userData.lastUsernameChange.toDate();
    const daysSince = (new Date() - lastChange) / (1000 * 60 * 60 * 24);

    if (daysSince < 10) {
      alert(`আপনি মাত্র ${Math.floor(daysSince)} দিন আগে ইউজারনেম পরিবর্তন করেছেন। নিয়ম অনুযায়ী ১০ দিন পর আবার পরিবর্তন করতে পারবেন!`);
      return;
    }
  }

  const newUsername = prompt("নতুন ইউজারনেম লিখুন (যেমন: @developer_shakib):");
  if (newUsername) {
    await updateDoc(userDocRef, {
      username: newUsername,
      lastUsernameChange: serverTimestamp()
    });
    document.getElementById('user-profile-handle').innerHTML = `${newUsername} <span class="badge">১০ দিনে ১ বার পরিবর্তনযোগ্য</span>`;
    alert("ইউজারনেম সফলভাবে পরিবর্তন করা হয়েছে!");
  }
};

// ==========================================
// 8. DIRECT MESSAGING (DM - Realtime Chat)
// ==========================================
window.sendDirectMessage = async function() {
  const input = document.getElementById('dm-message-input');
  const text = input.value.trim();
  if (!text) return;

  const chatList = document.getElementById('inbox-chat-list');
  const bubble = document.createElement('div');
  bubble.className = 'dm-bubble mine';
  bubble.textContent = text;
  chatList.appendChild(bubble);

  input.value = '';
};

// ==========================================
// 9. FEED TABS, MODALS & HELPERS
// ==========================================
window.filterFeedByTab = function(category) {
  loadVideos(category);
};

document.querySelectorAll('.feed-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.feed-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    loadVideos(tab.dataset.feed);
  });
});

window.toggleAutoScroll = function() {
  const btn = document.getElementById('auto-scroll-toggle');
  const feed = document.getElementById('video-feed');
  isAutoScrollOn = !isAutoScrollOn;

  if (isAutoScrollOn) {
    btn.classList.add('active');
    btn.innerHTML = '<i class="fa-solid fa-arrows-up-down"></i> Auto-Scroll: ON';
    autoScrollTimer = setInterval(() => {
      feed.scrollBy({ top: window.innerHeight, behavior: 'smooth' });
    }, 7000);
  } else {
    btn.classList.remove('active');
    btn.innerHTML = '<i class="fa-solid fa-arrows-up-down"></i> Auto-Scroll: OFF';
    clearInterval(autoScrollTimer);
  }
};

window.openModal = function(id) { document.getElementById(id).classList.add('open'); };
window.closeModal = function(id) { document.getElementById(id).classList.remove('open'); };
window.closeDrawer = function(id) { document.getElementById(id).classList.remove('open'); };
window.openCameraModal = function() { openModal('camera-modal'); };
window.openProfileModal = function() { openModal('profile-modal'); };
window.openInboxModal = function() { openModal('inbox-modal'); };
window.openShareDrawer = function(id) { currentActiveVideoId = id; document.getElementById('share-drawer').classList.add('open'); };

window.copyLink = function() {
  navigator.clipboard.writeText(window.location.href);
  alert("ভিডিও লিংক কপি হয়েছে!");
  closeDrawer('share-drawer');
};

window.repostCurrentVideo = function() {
  alert("ভিডিওটি আপনার ওয়ালে Repost হয়েছে!");
  closeDrawer('share-drawer');
};

window.downloadCurrentVideo = function() {
  alert("ডাউনলোড শুরু হচ্ছে...");
  closeDrawer('share-drawer');
};

window.markNotInterested = function() {
  alert("অ্যালগরিদম আপডেট করা হয়েছে। এই ক্যাটাগরির ভিডিও আর আসবে না।");
  closeDrawer('share-drawer');
};

window.toggleVisitorHistory = function() {
  const card = document.getElementById('visitors-list');
  card.style.display = card.style.display === 'none' ? 'block' : 'none';
};

window.switchNav = function(btn, type) {
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
};

// Prevent XSS
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

// Initial Run
loadVideos('fyp');